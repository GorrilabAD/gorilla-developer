$(document).ready(function () {
  $('.mobile-tab').hide();
  $('#burg').on('click', function () {
    $('.mobile-tab').slideToggle(800);
  })


});
